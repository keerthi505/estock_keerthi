export interface Company {
  id?: number;
  name?: string;
  code?: string;
  turnover?: string;
  ceo?: string;
  boardOfDirectors?: string;
  stockExchangeNames?: string;
  sectorName?: string;
  description?: string;
}
