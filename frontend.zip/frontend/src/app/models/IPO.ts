export interface IPO {
  id?: number;
  companyName?: string;
  stockExchangeName?: string;
  price?: number;
  shares?: number;
  openDateTime?: string;
  remarks?: string;
}
