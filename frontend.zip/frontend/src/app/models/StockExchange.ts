export interface StockExchange {
  id?: number;
  name?: string;
  description?: string;
  address?: string;
  remarks?: string;
}
